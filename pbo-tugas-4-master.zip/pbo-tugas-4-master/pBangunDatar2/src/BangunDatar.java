
public class BangunDatar {
    public double luas(){
        return 0;
    }
    public double keliling(){
        return 0;
    }
}
