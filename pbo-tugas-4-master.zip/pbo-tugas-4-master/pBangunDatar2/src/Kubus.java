
public class Kubus extends Persegi {
    public double volume(){
        return Math.pow(super.getSisi(),3);
    }
}
